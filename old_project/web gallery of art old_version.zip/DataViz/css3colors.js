$(function () {
	$('#css3colors').highcharts({
		series: [{
			type: "treemap",
            layoutAlgorithm: 'stripes',
            alternateStartingDirection: true,
            levels: [{
                level: 1,
                layoutAlgorithm: 'sliceAndDice',
                dataLabels: {
                    enabled: false,
                    align: 'left',
                    verticalAlign: 'top',
                    style: {
                        backgroundColor: 'rgba(0,0,0,0)',
                        fontSize: '10px',
                        fontWeight: 'bold'
                    }
                }
            }],
			data: [{
                name: 'Black',
				color: "black",
                value: 422
			}, {
                name: 'Darkslategrayk',
				color: "darkslategray",
                value: 350
			}, {
                name: 'Darkolivegreen',
				color: 'darkolivegreen',
                value: 266
			},{
                name: 'Sienna',
				color: 'sienna',
                value: 177
			},{
                name: 'Dimgrey',
				color: 'dimgrey',
                value: 160
			},{
                name: 'Saddlebrown',
				color: 'saddlebrown',
                value: 124
			},{
                name: 'Grey',
				color: 'grey',
                value: 116
			},{
                name: 'Rosybrow',
				color: 'rosybrown',
                value: 89
			},{
                name: 'Peru',
				color: 'peru',
                value: 85
			},{
                name: 'Tan',
				color: 'tan',
                value: 81
			},{
                name: 'Silver',
				color: 'silver',
                value: 59
			},{
                name: 'Darkgrey',
				color: 'darkgrey',
                value: 52
			},{
                name: 'Darkkhaki',
				color: 'darkkhaki',
                value: 49
			},{
                name: 'Burlywood',
				color: 'burlywood',
                value: 33
			},{
                name: 'Lightgray',
				color: 'lightgray',
                value: 31
			},{
                name: 'Wheat',
				color: 'wheat',
                value: 30
			},{
                name: 'Maroon',
				color: 'maroon',
                value: 19
			},{
                name: 'Gainsboro',
				color: 'gainsboro',
                value: 18
			},{
                name: 'Indianred',
				color: 'indianred',
                value: 15
			},{
                name: 'Lightslategrey',
				color: 'lightslategrey',
                value: 13
			},{
                name: 'Darksalmon',
				color: 'darksalmon',
                value: 10
			},{
                name: 'Brown',
				color: 'brown',
                value: 9
			},{
                name: 'Slategray',
				color: 'slategray',
                value: 9
			},{
                name: 'Sandybrown',
				color: 'sandybrown',
                value: 7
			},{
                name: 'Antiquewhite',
				color: 'antiquewhite',
                value: 6
			},{
                name: 'Darkslateblue',
				color: 'darkslateblue',
                value: 4
			},{
                name: 'Lightsteelblue',
				color: 'lightsteelblue',
                value: 4
			},{
                name: 'Bisque',
				color: 'bisque',
                value: 4
			},{
                name: 'Linen',
				color: 'linen',
                value: 3
			},{
                name: 'Palegoldenrod',
				color: 'palegoldenrod',
                value: 3
			},{
                name: 'Chocolate',
				color: 'chocolate',
                value: 3
			},{
                name: 'Khaki',
				color: 'khaki',
                value: 2
			},{
                name: 'Whitesmoke',
				color: 'whitesmoke',
                value: 2
			},{
                name: 'Darkseagreen',
				color: 'darkseagreen',
                value: 2
			},{
                name: 'Lavender',
				color: 'lavender',
                value: 2
			},{
                name: 'Darkgoldenrod',
				color: 'darkgoldenrod',
                value: 1
			},{
                name: 'Snow',
				color: 'snow',
                value: 1
			},{
                name: 'White',
				color: 'white',
                value: 1
			},{
                name: 'Beige',
				color: 'beige',
                value: 1
			},{
                name: 'Firebrick',
				color: 'firebrick',
                value: 1
			},{
                name: 'Steelblue',                                
				color: 'steelblue',
                value: 1
			},{
                name: 'Midnightblue', 
				color: 'midnightblue',
                value: 1
			},{
                name: 'Cadetblue',
				color: 'cadetblue',
                value: 1
			},{
                name: 'Goldenrod',
				color: 'goldenrod',
                value: 1
			},{
                name: 'Navajowhite',
				color: 'navajowhite',
                value: 1
			}]
		}],
		title: {
            text: ''
		}
	});
});