# -*- coding: utf-8 -*-


import scrapy
from uffizi.items import UffiziItem



class UffiziSpider(scrapy.Spider):
	name = "uffizi"
	
	inFile = open('testquadri.csv', 'r')
	testo = inFile.read()
	inFile.close()
	start_urls = testo.split(";\r\n")
	print start_urls
	
	#dividi la stringa 'testo' usando il separatore ";\r\n" e crea la lista di link
		
	

	
 	
	   
	def parse(self, response):
		 for sel in response.xpath('*'):
			item = UffiziItem()
			item['img'] = sel.xpath('*').extract()
            		yield item

#/html/body/table[2]/tbody/tr[1]/td[1]/a/img/@src
