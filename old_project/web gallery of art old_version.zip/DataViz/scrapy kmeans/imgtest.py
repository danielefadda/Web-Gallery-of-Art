from colorweave import palette
import csv

inFile = open('imgtest.csv', 'r')
testo = inFile.read()
inFile.close()
quadri = testo.split("\n")


#The palette method takes the image from the URL and returns the hex codes of the dominant colors as a list.


for i in quadri:
	print i, palette(url=i, n=9, format="fullest", mode="kmeans") 




	
# Returns the list of dominant colors using k-means clustering algorithm (bit slower than the default method)
